// Dyne Right — Single Page Website with Logo & Custom Photos
import React from 'react'

export default function Website() {
  return (
    <div className="min-h-screen w-full bg-white text-slate-800">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/80 border-b border-slate-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <img src="/images/dyne-right-logo.png" alt="Dyne Right Logo" className="h-12 w-auto" />
            <div>
              <p className="font-semibold leading-tight">Dyne Right</p>
              <p className="text-xs text-slate-500 -mt-0.5">Quality Work Done Right the First Time</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:text-slate-900 text-slate-600">Services</a>
            <a href="#portfolio" className="hover:text-slate-900 text-slate-600">Portfolio</a>
            <a href="#reviews" className="hover:text-slate-900 text-slate-600">Reviews</a>
            <a href="#about" className="hover:text-slate-900 text-slate-600">About</a>
            <a href="#contact" className="hover:text-slate-900 text-slate-600">Contact</a>
          </nav>
          <div className="hidden sm:flex items-center gap-3">
            <a href="#contact" className="rounded-2xl border border-slate-300 px-4 py-2 text-sm hover:bg-slate-50">Get a Quote</a>
            <a href="tel:+1-000-000-0000" className="rounded-2xl bg-slate-900 text-white px-4 py-2 text-sm shadow-sm hover:shadow">Call Now</a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 to-slate-100" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900">
              Remodeling & Restoration in Charlotte–Rock Hill
            </h1>
            <p className="mt-4 text-lg text-slate-600 max-w-prose">
              Bathrooms, kitchens, flooring, drywall, painting, trim, and full-scale transformations. Fully insured and proudly serving North & South Carolina.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#contact" className="rounded-2xl bg-slate-900 text-white px-5 py-2.5 text-sm shadow hover:shadow-md">Request Free Estimate</a>
              <a href="#services" className="rounded-2xl border border-slate-300 px-5 py-2.5 text-sm hover:bg-white">Explore Services</a>
            </div>
          </div>
          <div className="aspect-video rounded-3xl bg-[url('/images/hero-remodel.jpg')] bg-cover bg-center shadow-xl" aria-label="Dyne Right featured project" />
        </div>
      </section>

      {/* Badges */}
      <section className="py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {['Bathrooms & Kitchens','LVP, Tile & Hardwood','Drywall & Paint','Insurance Restoration'].map((t) => (
            <div key={t} className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-center text-sm font-medium shadow-sm">{t}</div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-16 md:py-24 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="md:flex items-end justify-between">
            <h2 className="text-2xl md:text-3xl font-bold">Services</h2>
            <p className="text-slate-600 mt-2 md:mt-0">Craftsmanship you can trust, delivered on schedule.</p>
          </div>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((s) => (
              <div key={s.title} className="rounded-2xl bg-white border border-slate-200 p-6 shadow-sm hover:shadow">
                <div className="h-40 rounded-xl bg-cover bg-center" style={{backgroundImage: `url(${s.image})`}} aria-label={s.title} />
                <h3 className="mt-4 text-lg font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm text-slate-600">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio */}
      <section id="portfolio" className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold">Recent Work</h2>
          <p className="text-slate-600 mt-2">Before/after galleries that show our detail and finish.</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {portfolio.map((p, i) => (
              <figure key={i} className="group rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-sm">
                <div className="aspect-[4/3] bg-cover bg-center" style={{backgroundImage:`url(${p})`}} />
                <figcaption className="px-4 py-3 text-sm text-slate-600">Project #{i+1}</figcaption>
              </figure>
            ))}
          </div>
          <div className="mt-6">
            <a href="#contact" className="text-sm font-medium underline underline-offset-4">Want something similar? Get a quote →</a>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section id="reviews" className="py-16 md:py-24 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold">What Clients Say</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <blockquote key={i} className="rounded-2xl bg-white border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center gap-1 text-amber-500">
                  {Array.from({length:5}).map((_,i)=>(<span key={i}>★</span>))}
                </div>
                <p className="mt-3 text-slate-700">“{t.quote}”</p>
                <footer className="mt-3 text-sm text-slate-500">— {t.name}</footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-10 items-center">
          <div className="aspect-video rounded-3xl bg-[url('/images/project1.jpg')] bg-cover bg-center shadow-xl" />
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">About Dyne Right</h2>
            <p className="mt-3 text-slate-600">
              With 7+ years in remodeling and insurance restoration, we deliver dependable scheduling, clear communication, and meticulous finish work. We believe in doing it right the first time—so your space looks great and lasts.
            </p>
            <ul className="mt-4 grid gap-2 text-sm text-slate-700 list-disc pl-5">
              <li>Fully insured • Registered to operate in NC & SC</li>
              <li>Bathroom & kitchen remodels, flooring (LVP/tile/hardwood), drywall, paint, trim</li>
              <li>Serving Charlotte–Mecklenburg, Rock Hill, Lake Wylie & surrounding</li>
            </ul>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold">FAQ</h2>
          <div className="mt-6 grid gap-4">
            {faqs.map((f, i) => (
              <details key={i} className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <summary className="cursor-pointer list-none font-semibold flex items-center justify-between">
                  {f.q}
                  <span className="ml-4 text-slate-400 group-open:rotate-45 transition">+</span>
                </summary>
                <p className="mt-3 text-slate-600 text-sm">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold">Get a Free Estimate</h2>
              <p className="mt-2 text-slate-600">Tell us about your project and we’ll reply with next steps.</p>
              <form className="mt-6 grid gap-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <input className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Full name" />
                  <input className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Phone or email" />
                </div>
                <input className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="City / Service area" />
                <textarea className="w-full rounded-xl border border-slate-300 px-4 py-3 min-h-[120px]" placeholder="Project details (room, timeline, budget)"></textarea>
                <button type="button" className="rounded-2xl bg-slate-900 text-white px-5 py-3 text-sm shadow hover:shadow-md w-fit">Send Request</button>
                <p className="text-xs text-slate-500">By submitting, you agree we may contact you about your project. We do not sell personal info.</p>
              </form>
            </div>
            <div className="rounded-2xl border border-slate-200 p-6 bg-slate-50">
              <h3 className="font-semibold">Contact</h3>
              <div className="mt-3 text-sm text-slate-700">
                <p>Phone: <a className="underline underline-offset-4" href="tel:+1-000-000-0000">(000) 000‑0000</a></p>
                <p>Email: <a className="underline underline-offset-4" href="mailto:hello@dyneright.com">hello@dyneright.com</a></p>
                <p>Website: <a className="underline underline-offset-4" href="https://dyneright.com">dyneright.com</a></p>
                <p>Hours: Mon–Fri 8am–6pm</p>
                <p>Service Area: Charlotte–Mecklenburg • Rock Hill • Lake Wylie</p>
              </div>
              <div className="mt-6">
                <div className="aspect-video w-full rounded-xl bg-[url('/images/project2.jpg')] bg-cover bg-center" aria-label="Map area" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="rounded-3xl bg-slate-900 p-10 text-white shadow-xl">
            <h3 className="text-xl md:text-2xl font-bold">Ready to start your project?</h3>
            <p className="mt-2 text-slate-300">Get a fast, detailed quote and a schedule you can count on.</p>
            <a href="#contact" className="inline-block mt-4 rounded-2xl bg-white text-slate-900 px-5 py-3 text-sm font-medium shadow hover:shadow-md">Request Free Estimate</a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 grid md:grid-cols-3 gap-6 items-start">
          <div>
            <div className="flex items-center gap-3">
              <img src="/images/dyne-right-logo.png" alt="Dyne Right Logo" className="h-9 w-auto" />
              <p className="font-semibold">Dyne Right</p>
            </div>
            <p className="mt-3 text-sm text-slate-600 max-w-sm">
              Remodeling, restoration, and finish carpentry across the Charlotte–Rock Hill corridor. Fully insured. Registered to operate in NC & SC.
            </p>
          </div>
          <div className="text-sm">
            <p className="font-semibold">Services</p>
            <ul className="mt-2 grid gap-1 text-slate-600">
              <li>Bathroom Remodels</li>
              <li>Kitchen Remodels</li>
              <li>Flooring (LVP, Tile, Hardwood)</li>
              <li>Drywall & Painting</li>
              <li>Trim & Carpentry</li>
              <li>Insurance Restoration</li>
            </ul>
          </div>
          <div className="text-sm">
            <p className="font-semibold">Get in touch</p>
            <ul className="mt-2 grid gap-1 text-slate-600">
              <li><a className="underline underline-offset-4" href="mailto:hello@dyneright.com">hello@dyneright.com</a></li>
              <li><a className="underline underline-offset-4" href="tel:+1-000-000-0000">(000) 000‑0000</a></li>
              <li><a className="underline underline-offset-4" href="#contact">Request Estimate</a></li>
            </ul>
          </div>
        </div>
        <div className="text-xs text-slate-500 py-4 text-center">© {new Date().getFullYear()} Dyne Right. All rights reserved.</div>
      </footer>
    </div>
  )
}

const services = [
  { title: 'Bathroom Remodels', desc: 'Tub/shower conversions, waterproofing, tile, vanities, lighting, and clean modern finishes.', image: '/images/project1.jpg' },
  { title: 'Kitchen Remodels', desc: 'Cabinetry, countertops, backsplashes, layout updates, and functional storage.', image: '/images/project2.jpg' },
  { title: 'Flooring (LVP/Tile/Wood)', desc: 'Expert prep, leveling, and installation for durable, beautiful floors.', image: '/images/project3.jpg' },
  { title: 'Drywall & Painting', desc: 'Repairs, finishing, textures, and crisp interior/exterior paint.', image: '/images/project1.jpg' },
  { title: 'Trim & Carpentry', desc: 'Crown, base, doors, shelving, and custom woodwork to elevate your space.', image: '/images/project2.jpg' },
  { title: 'Insurance Restoration', desc: 'Seamless rebuilds after water or storm damage with clear documentation.', image: '/images/project3.jpg' },
]

const portfolio = ['/images/project1.jpg','/images/project2.jpg','/images/project3.jpg','/images/project1.jpg','/images/project2.jpg','/images/project3.jpg']

const testimonials = [
  { name: 'Mary & David, Charlotte', quote: 'Professional, punctual, and the results are gorgeous. Our floors and trim look incredible.' },
  { name: 'Andrew, Rock Hill', quote: 'Clear communication and flawless tile work. Will hire again for our kitchen remodel.' },
  { name: 'Halley D., Lake Wylie', quote: 'They handled restoration after a leak and made it better than before. Highly recommend!' },
]

const faqs = [
  { q: 'Are you licensed?', a: 'We are fully insured and registered to operate in North & South Carolina. For projects requiring a GC license, we partner with trusted licensed GCs.' },
  { q: 'What areas do you serve?', a: 'Charlotte–Mecklenburg, Rock Hill, Lake Wylie, and surrounding communities.' },
  { q: 'Do you offer free estimates?', a: 'Yes—share details through the form and we’ll provide a clear, itemized proposal.' },
  { q: 'What kinds of projects do you take?', a: 'Bathroom/kitchen remodels, flooring, drywall/paint, trim/carpentry, and insurance restoration.' },
]
